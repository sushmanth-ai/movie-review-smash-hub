import { useNavigate } from "react-router-dom";
import { useViewerCount } from "@/hooks/useViewerCount";
import { motion } from "framer-motion";
import { Eye, Sparkles } from "lucide-react";

export default function LandingPage() {
  const viewerCount = useViewerCount();
  const navigate = useNavigate();

  return (
    <div className="flex min-h-screen items-center justify-center bg-background p-4">
      <motion.div
        initial={{ opacity: 0, y: 30, scale: 0.95 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.6, type: "spring", damping: 15 }}
        onClick={() => navigate("/draw")}
        className="group cursor-pointer rounded-2xl border-2 border-primary/30 bg-card/80 px-10 py-12 text-center shadow-2xl backdrop-blur-sm transition-all duration-300 hover:border-primary/60 hover:shadow-primary/20 hover:scale-[1.03] md:px-16 md:py-16"
      >
        <motion.div
          animate={{ rotate: [0, 5, -5, 0] }}
          transition={{ repeat: Infinity, duration: 3, ease: "easeInOut" }}
        >
          <Sparkles className="mx-auto mb-6 h-16 w-16 text-primary" />
        </motion.div>

        <h1 className="mb-3 text-4xl font-bold md:text-5xl">
          <span className="gold-glow">🎰 SM Lucky Draw</span>
        </h1>

        <p className="mb-8 text-lg text-muted-foreground">
          Tap to enter the draw
        </p>

        <div className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-secondary/50 px-5 py-2.5">
          <Eye className="h-5 w-5 text-primary" />
          <span className="text-lg font-semibold text-primary">{viewerCount}</span>
          <span className="text-sm text-muted-foreground">watching live</span>
        </div>

        <button
          className="mt-10 rounded-full bg-primary px-8 py-3 text-sm font-semibold text-primary-foreground transition-all hover:opacity-90"
        >
          Click to Enter →
        </button>
      </motion.div>
    </div>
  );
}
