import { useEffect, useState, useRef, useCallback } from "react";
import { useParticipants } from "@/hooks/useParticipants";
import { useDrawState } from "@/hooks/useDrawState";
import { useViewerCount } from "@/hooks/useViewerCount";
import { motion, AnimatePresence } from "framer-motion";
import confetti from "canvas-confetti";
import { Trophy, Users, Sparkles, Eye, Timer } from "lucide-react";
import LiveChat from "@/components/LiveChat";

export default function PublicView() {
  const { participants } = useParticipants();
  const { drawState, draws } = useDrawState();
  const viewerCount = useViewerCount();
  const [shuffleName, setShuffleName] = useState("");
  const shuffleInterval = useRef<ReturnType<typeof setInterval> | null>(null);
  const prevStatus = useRef<string>("idle");
  const [countdown, setCountdown] = useState<{ hours: number; minutes: number; seconds: number } | null>(null);

  // Countdown timer
  useEffect(() => {
    if (!drawState?.countdown_target) {
      setCountdown(null);
      return;
    }

    const tick = () => {
      const target = new Date(drawState.countdown_target!).getTime();
      const now = Date.now();
      const diff = target - now;
      if (diff <= 0) {
        setCountdown(null);
        return;
      }
      const hours = Math.floor(diff / 3600000);
      const minutes = Math.floor((diff % 3600000) / 60000);
      const seconds = Math.floor((diff % 60000) / 1000);
      setCountdown({ hours, minutes, seconds });
    };

    tick();
    const interval = setInterval(tick, 1000);
    return () => clearInterval(interval);
  }, [drawState?.countdown_target]);

  // Slow thrilling shuffle animation — minimum 15 seconds
  useEffect(() => {
    if (drawState?.status === "shuffling" && participants.length > 0) {
      const allNames = participants.map((p) => p.name);
      let step = 0;
      const totalSteps = 250; // ~50 seconds duration

      const tick = () => {
        step++;
        const randomIndex = Math.floor(Math.random() * allNames.length);
        setShuffleName(allNames[randomIndex]);

        if (step >= totalSteps) return;

        const progress = step / totalSteps;

        // Phase 1 (0-40%): fast and frantic — 60-100ms
        // Phase 2 (40-75%): medium slowdown — 100-300ms
        // Phase 3 (75-95%): dramatic slowdown — 300-800ms
        // Phase 4 (95-100%): suspenseful crawl — 800-1500ms
        let delay: number;
        if (progress < 0.3) {
          delay = 100 + progress * 150;
        } else if (progress < 0.6) {
          const p = (progress - 0.3) / 0.3;
          delay = 150 + p * p * 350;
        } else if (progress < 0.85) {
          const p = (progress - 0.6) / 0.25;
          delay = 500 + p * p * p * 900;
        } else {
          const p = (progress - 0.85) / 0.15;
          delay = 1400 + p * 1800;
        }

        shuffleInterval.current = setTimeout(tick, delay) as unknown as ReturnType<typeof setInterval>;
      };

      tick();

      return () => {
        if (shuffleInterval.current) clearTimeout(shuffleInterval.current as unknown as number);
      };
    } else {
      if (shuffleInterval.current) clearTimeout(shuffleInterval.current as unknown as number);
    }
  }, [drawState?.status, participants]);

  // Confetti on winner reveal
  const fireConfetti = useCallback(() => {
    const duration = 4000;
    const end = Date.now() + duration;
    const colors = ["#FFD700", "#FFA500", "#FF6347", "#00CED1", "#7B68EE"];

    const frame = () => {
      confetti({
        particleCount: 5,
        angle: 60,
        spread: 55,
        origin: { x: 0, y: 0.7 },
        colors
      });
      confetti({
        particleCount: 5,
        angle: 120,
        spread: 55,
        origin: { x: 1, y: 0.7 },
        colors
      });
      if (Date.now() < end) requestAnimationFrame(frame);
    };
    frame();
  }, []);

  useEffect(() => {
    if (prevStatus.current !== "winner" && drawState?.status === "winner") {
      fireConfetti();
    }
    prevStatus.current = drawState?.status || "idle";
  }, [drawState?.status, fireConfetti]);

  const isIdle = drawState?.status === "idle";
  const isShuffling = drawState?.status === "shuffling";
  const isWinner = drawState?.status === "winner";
  const winnerNames = drawState?.winner_names || [];

  return (
    <div className="relative flex min-h-screen flex-col overflow-hidden" style={{ background: "linear-gradient(135deg, hsl(280 60% 12%), hsl(220 50% 10%), hsl(340 50% 12%), hsl(45 60% 10%))" }}>
      {/* Floating Balloons */}
      <div className="pointer-events-none fixed inset-0 z-0 overflow-hidden">
        {["🎈", "🎈", "🎈", "🎈", "🎈", "🎈", "🎉", "🎊", "🎈", "🎈"].map((emoji, i) => (
          <motion.div
            key={`balloon-${i}`}
            className="absolute text-3xl md:text-5xl"
            style={{ left: `${5 + i * 10}%`, bottom: "-60px" }}
            animate={{
              y: [0, -window.innerHeight - 200],
              x: [0, Math.sin(i) * 40, 0],
              rotate: [0, i % 2 === 0 ? 15 : -15, 0],
            }}
            transition={{
              duration: 12 + i * 2,
              repeat: Infinity,
              delay: i * 1.5,
              ease: "linear",
            }}
          >
            {emoji}
          </motion.div>
        ))}
      </div>

      {/* Floating Confetti Papers */}
      <div className="pointer-events-none fixed inset-0 z-0 overflow-hidden">
        {Array.from({ length: 20 }).map((_, i) => (
          <motion.div
            key={`paper-${i}`}
            className="absolute h-3 w-2 rounded-sm md:h-4 md:w-3"
            style={{
              left: `${Math.random() * 100}%`,
              top: "-20px",
              backgroundColor: ["#FFD700", "#FF6347", "#00CED1", "#7B68EE", "#FF69B4", "#32CD32", "#FFA500"][i % 7],
            }}
            animate={{
              y: [0, window.innerHeight + 100],
              x: [0, Math.sin(i * 0.7) * 60, Math.cos(i * 0.5) * 40, 0],
              rotate: [0, 360 * (i % 2 === 0 ? 1 : -1)],
            }}
            transition={{
              duration: 8 + Math.random() * 6,
              repeat: Infinity,
              delay: Math.random() * 10,
              ease: "linear",
            }}
          />
        ))}
      </div>

      {/* Gradient Orbs */}
      <div className="pointer-events-none fixed inset-0 z-0">
        <div className="absolute -left-32 -top-32 h-96 w-96 rounded-full bg-purple-500/10 blur-3xl" />
        <div className="absolute -right-32 top-1/3 h-80 w-80 rounded-full bg-pink-500/10 blur-3xl" />
        <div className="absolute bottom-0 left-1/3 h-72 w-72 rounded-full bg-cyan-500/10 blur-3xl" />
        <div className="absolute -bottom-20 right-1/4 h-64 w-64 rounded-full bg-yellow-500/10 blur-3xl" />
      </div>

      {/* Header */}
      <header className="relative z-10 border-b border-border/50 bg-card/30 backdrop-blur-md">
        <div className="mx-auto flex max-w-5xl items-center justify-between px-4 py-4">
          <h1 className="text-2xl font-bold md:text-3xl">
            <span className="gold-glow">🎰 SM Lucky Draw</span>
          </h1>
          <div className="flex items-center gap-4 text-muted-foreground">
            



            <div className="flex items-center gap-1.5">
              <Users className="h-4 w-4" />
              <span className="text-sm">{participants.length} participants</span>
            </div>
          </div>
        </div>
      </header>

      <main className="relative z-10 mx-auto flex w-full max-w-5xl flex-1 flex-col gap-6 p-4 md:p-8">
        {/* Draw Area */}
        <section className="flex flex-col items-center justify-center rounded-2xl border border-border/50 bg-card/60 p-8 md:p-16 backdrop-blur">
          <AnimatePresence mode="wait">
            {isIdle && countdown &&
            <motion.div
              key="countdown"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="text-center">

                <Timer className="mx-auto mb-4 h-16 w-16 text-primary" />
                <p className="mb-6 text-lg uppercase tracking-widest text-muted-foreground">Draw starts in</p>
                <div className="flex items-center justify-center gap-3">
                  {countdown.hours > 0 && (
                    <div className="flex flex-col items-center rounded-xl border border-primary/30 bg-secondary/50 px-5 py-4">
                      <span className="text-4xl font-bold text-primary md:text-6xl gold-glow">{String(countdown.hours).padStart(2, "0")}</span>
                      <span className="mt-1 text-xs uppercase text-muted-foreground">Hours</span>
                    </div>
                  )}
                  {countdown.hours > 0 && <span className="text-3xl font-bold text-primary/50">:</span>}
                  <div className="flex flex-col items-center rounded-xl border border-primary/30 bg-secondary/50 px-5 py-4">
                    <span className="text-4xl font-bold text-primary md:text-6xl gold-glow">{String(countdown.minutes).padStart(2, "0")}</span>
                    <span className="mt-1 text-xs uppercase text-muted-foreground">Minutes</span>
                  </div>
                  <span className="text-3xl font-bold text-primary/50">:</span>
                  <div className="flex flex-col items-center rounded-xl border border-primary/30 bg-secondary/50 px-5 py-4">
                    <motion.span
                      key={countdown.seconds}
                      initial={{ scale: 1.2 }}
                      animate={{ scale: 1 }}
                      className="text-4xl font-bold text-primary md:text-6xl gold-glow"
                    >
                      {String(countdown.seconds).padStart(2, "0")}
                    </motion.span>
                    <span className="mt-1 text-xs uppercase text-muted-foreground">Seconds</span>
                  </div>
                </div>
              </motion.div>
            }

            {isIdle && !countdown &&
            <motion.div
              key="idle"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="text-center">

                <Sparkles className="mx-auto mb-4 h-16 w-16 text-primary/40" />
                <p className="text-xl text-muted-foreground">Waiting for the draw to start...</p>
              </motion.div>
            }

            {isShuffling &&
            <motion.div
              key="shuffling"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="text-center">

                <p className="mb-4 text-sm uppercase tracking-widest text-muted-foreground animate-pulse">Selecting winner...</p>
                <motion.div
                className="rounded-xl border-2 border-primary/50 bg-secondary/50 px-12 py-8 winner-glow"
                animate={{
                  scale: [1, 1.05, 1],
                  boxShadow: [
                  "0 0 20px hsl(var(--primary) / 0.3)",
                  "0 0 40px hsl(var(--primary) / 0.6)",
                  "0 0 20px hsl(var(--primary) / 0.3)"]

                }}
                transition={{ repeat: Infinity, duration: 0.5 }}>

                  <motion.p
                  key={shuffleName}
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.08 }}
                  className="text-4xl font-bold text-primary md:text-6xl gold-glow">

                    {shuffleName || "..."}
                  </motion.p>
                </motion.div>
              </motion.div>
            }

            {isWinner && winnerNames.length > 0 &&
            <motion.div
              key="winner"
              initial={{ opacity: 0, scale: 0.5 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ type: "spring", damping: 12 }}
              className="text-center">

                <Trophy className="mx-auto mb-4 h-16 w-16 text-primary" />
                <p className="mb-2 text-sm uppercase tracking-widest text-muted-foreground">
                  {winnerNames.length > 1 ? "Winners!" : "Winner!"}
                </p>
                <div className="space-y-3">
                  {winnerNames.map((name, i) =>
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.3 }}
                  className="rounded-xl border-2 border-primary bg-secondary/50 px-12 py-6 winner-glow">

                      <p className="text-4xl font-bold text-primary md:text-5xl gold-glow">{name}</p>
                    </motion.div>
                )}
                </div>
              </motion.div>
            }
          </AnimatePresence>
        </section>

        {/* Participant List & Recent Winners side by side */}
        <div className="grid gap-6 md:grid-cols-2">
          {/* Participants */}
          <section className="rounded-xl border border-border/50 bg-card/60 p-6 backdrop-blur">
            <h2 className="mb-4 flex items-center gap-2 text-lg font-semibold">
              <Users className="h-5 w-5 text-primary" /> Participants
            </h2>
            <div className="max-h-[300px] overflow-auto">
              {participants.length === 0 ?
              <p className="text-center text-muted-foreground">No participants yet</p> :

              <div className="flex flex-wrap gap-2">
                  {participants.map((p) =>
                <span key={p.id} className="rounded-full border border-border bg-secondary/50 px-3 py-1 text-sm">
                      {p.name}
                    </span>
                )}
                </div>
              }
            </div>
          </section>

          {/* Recent Winners */}
          <section className="rounded-xl border border-border/50 bg-card/60 p-6 backdrop-blur">
            <h2 className="mb-4 flex items-center gap-2 text-lg font-semibold">
              <Trophy className="h-5 w-5 text-primary" /> Recent Winners
            </h2>
            <div className="max-h-[300px] space-y-2 overflow-auto">
              {draws.length === 0 ?
              <p className="text-center text-muted-foreground">No draws yet</p> :

              draws.slice(0, 10).map((d) =>
              <div key={d.id} className="flex items-center justify-between rounded-lg border border-border/30 bg-secondary/30 px-4 py-2">
                    <span className="font-semibold text-primary">{d.winner_names.join(", ")}</span>
                    <span className="text-xs text-muted-foreground">{new Date(d.created_at).toLocaleDateString()}</span>
                  </div>
              )
              }
            </div>
          </section>
        </div>
      </main>

      <footer className="relative z-10 border-t border-border/50 py-4 text-center text-sm text-muted-foreground">
        SM Lucky Draw © {new Date().getFullYear()}
      </footer>

      <LiveChat />
    </div>);

}