import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useParticipants } from "@/hooks/useParticipants";
import { useDrawState } from "@/hooks/useDrawState";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { LogOut, Plus, Trash2, Pencil, Sparkles, Users, Trophy, History, FileDown, Timer } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import jsPDF from "jspdf";

export default function AdminDashboard() {
  const { signOut } = useAuth();
  const { participants, addParticipant, addBulkParticipants, updateParticipant, deleteParticipant, clearAll } = useParticipants();
  const { drawState, draws, startDraw, deleteDraw, clearDrawHistory, setCountdown, clearCountdown } = useDrawState();

  const [newName, setNewName] = useState("");
  const [bulkNames, setBulkNames] = useState("");
  const [showBulk, setShowBulk] = useState(false);
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [editName, setEditName] = useState("");
  const [multiCount, setMultiCount] = useState(1);
  const [showMultiDraw, setShowMultiDraw] = useState(false);
  const [drawLoading, setDrawLoading] = useState(false);
  const [showClearHistory, setShowClearHistory] = useState(false);
  const [countdownMinutes, setCountdownMinutes] = useState(5);

  const handleAddOne = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim()) return;
    const { error } = await addParticipant(newName);
    if (error) toast({ title: "Error", description: error.message, variant: "destructive" });
    else setNewName("");
  };

  const handleBulkAdd = async () => {
    const names = bulkNames.split("\n").filter((n) => n.trim());
    if (names.length === 0) return;
    const { error } = await addBulkParticipants(names);
    if (error) toast({ title: "Error", description: error.message, variant: "destructive" });
    else { setBulkNames(""); setShowBulk(false); }
  };

  const handleEdit = async () => {
    if (!editId || !editName.trim()) return;
    await updateParticipant(editId, editName);
    setEditId(null);
    setEditName("");
  };

  const handleClearAll = async () => {
    await clearAll();
    setShowClearConfirm(false);
  };

  const handleDraw = async (count: number) => {
    setDrawLoading(true);
    setShowMultiDraw(false);
    const { error } = await startDraw(count);
    if (error) toast({ title: "Draw Error", description: String(error), variant: "destructive" });
    setDrawLoading(false);
  };

  const isDrawing = drawState?.status === "shuffling";

  return (
    <div className="min-h-screen p-4 md:p-8">
      {/* Header */}
      <div className="mb-8 flex items-center justify-between">
        <h1 className="text-3xl font-bold gold-glow">🎰 SM Lucky Draw — Admin</h1>
        <Button variant="ghost" onClick={signOut}>
          <LogOut className="mr-2 h-4 w-4" /> Logout
        </Button>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Left: Participant Management */}
        <div className="space-y-4">
          <Card className="border-border/50 bg-card/80">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5 text-primary" /> Participants ({participants.length})
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Add single */}
              <form onSubmit={handleAddOne} className="flex gap-2">
                <Input placeholder="Add participant name" value={newName} onChange={(e) => setNewName(e.target.value)} />
                <Button type="submit" size="icon"><Plus className="h-4 w-4" /></Button>
              </form>

              {/* Bulk / Clear / Export buttons */}
              <div className="flex flex-wrap gap-2">
                <Button variant="secondary" size="sm" onClick={() => setShowBulk(true)}>Bulk Add</Button>
                <Button variant="destructive" size="sm" onClick={() => setShowClearConfirm(true)} disabled={participants.length === 0}>
                  <Trash2 className="mr-1 h-3 w-3" /> Clear All
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  disabled={participants.length === 0}
                  onClick={() => {
                    const doc = new jsPDF();
                    doc.setFontSize(18);
                    doc.text("SM Lucky Draw - Participants", 14, 20);
                    doc.setFontSize(10);
                    doc.text(`Total: ${participants.length} | Exported: ${new Date().toLocaleString()}`, 14, 28);
                    doc.setFontSize(12);
                    participants.forEach((p, i) => {
                      const y = 38 + i * 8;
                      if (y > 280) { doc.addPage(); }
                      const pageY = y > 280 ? 20 + ((i * 8) % 260) : y;
                      doc.text(`${i + 1}. ${p.name}`, 14, pageY);
                    });
                    doc.save("participants.pdf");
                  }}
                >
                  <FileDown className="mr-1 h-3 w-3" /> Export PDF
                </Button>
              </div>

              {/* Participant table */}
              <div className="max-h-[400px] overflow-auto rounded-md border border-border/50">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>#</TableHead>
                      <TableHead>Name</TableHead>
                      <TableHead className="w-[100px]">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {participants.map((p, i) => (
                      <TableRow key={p.id}>
                        <TableCell className="text-muted-foreground">{i + 1}</TableCell>
                        <TableCell>{p.name}</TableCell>
                        <TableCell>
                          <div className="flex gap-1">
                            <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => { setEditId(p.id); setEditName(p.name); }}>
                              <Pencil className="h-3 w-3" />
                            </Button>
                            <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive" onClick={() => deleteParticipant(p.id)}>
                              <Trash2 className="h-3 w-3" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                    {participants.length === 0 && (
                      <TableRow><TableCell colSpan={3} className="text-center text-muted-foreground">No participants yet</TableCell></TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>

          {/* Countdown + Draw Controls */}
          <Card className="border-primary/30 bg-card/80">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Timer className="h-5 w-5 text-primary" /> Countdown Timer
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {drawState?.countdown_target && new Date(drawState.countdown_target) > new Date() ? (
                <div className="space-y-2">
                  <p className="text-sm text-muted-foreground">
                    Countdown active — draw at{" "}
                    <span className="font-semibold text-primary">
                      {new Date(drawState.countdown_target).toLocaleTimeString()}
                    </span>
                  </p>
                  <Button variant="destructive" size="sm" onClick={clearCountdown}>
                    Cancel Countdown
                  </Button>
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <Input
                    type="number"
                    min={1}
                    max={60}
                    value={countdownMinutes}
                    onChange={(e) => setCountdownMinutes(Number(e.target.value))}
                    className="w-24"
                  />
                  <span className="text-sm text-muted-foreground">minutes</span>
                  <Button
                    size="sm"
                    onClick={() => setCountdown(countdownMinutes)}
                    disabled={participants.length === 0}
                  >
                    <Timer className="mr-1 h-3 w-3" /> Set Countdown
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="border-primary/30 bg-card/80">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Sparkles className="h-5 w-5 text-primary" /> Draw Controls
              </CardTitle>
            </CardHeader>
            <CardContent className="flex flex-wrap gap-3">
              <Button
                onClick={() => handleDraw(1)}
                disabled={drawLoading || isDrawing || participants.length === 0}
                className="bg-primary text-primary-foreground hover:bg-primary/90"
              >
                <Trophy className="mr-2 h-4 w-4" />
                {isDrawing ? "Drawing..." : "Start Lucky Draw"}
              </Button>
              <Button
                variant="secondary"
                onClick={() => setShowMultiDraw(true)}
                disabled={drawLoading || isDrawing || participants.length < 2}
              >
                <Users className="mr-2 h-4 w-4" /> Start Multi Draw
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Right: Draw History */}
        <Card className="border-border/50 bg-card/80">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span className="flex items-center gap-2">
                <History className="h-5 w-5 text-primary" /> Draw History
              </span>
              {draws.length > 0 && (
                <Button variant="destructive" size="sm" onClick={() => setShowClearHistory(true)}>
                  <Trash2 className="mr-1 h-3 w-3" /> Clear History
                </Button>
              )}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="max-h-[500px] overflow-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Date</TableHead>
                    <TableHead>Winner(s)</TableHead>
                    <TableHead>Pool</TableHead>
                    <TableHead className="w-[50px]"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {draws.map((d) => (
                    <TableRow key={d.id}>
                      <TableCell className="text-muted-foreground text-xs">
                        {new Date(d.created_at).toLocaleString()}
                      </TableCell>
                      <TableCell className="font-semibold text-primary">
                        {d.winner_names.join(", ")}
                      </TableCell>
                      <TableCell>{d.participant_count}</TableCell>
                      <TableCell>
                        <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive" onClick={() => deleteDraw(d.id)}>
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                  {draws.length === 0 && (
                    <TableRow><TableCell colSpan={3} className="text-center text-muted-foreground">No draws yet</TableCell></TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Bulk Add Dialog */}
      <Dialog open={showBulk} onOpenChange={setShowBulk}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Bulk Add Participants</DialogTitle>
            <DialogDescription>Enter one name per line</DialogDescription>
          </DialogHeader>
          <Textarea rows={8} placeholder={"John Doe\nJane Smith\nAlex Johnson"} value={bulkNames} onChange={(e) => setBulkNames(e.target.value)} />
          <DialogFooter>
            <Button onClick={handleBulkAdd}>Add All</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Dialog */}
      <Dialog open={!!editId} onOpenChange={() => setEditId(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Participant</DialogTitle>
            <DialogDescription>Update the participant name</DialogDescription>
          </DialogHeader>
          <Input value={editName} onChange={(e) => setEditName(e.target.value)} />
          <DialogFooter>
            <Button onClick={handleEdit}>Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Clear Confirm Dialog */}
      <Dialog open={showClearConfirm} onOpenChange={setShowClearConfirm}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Clear All Participants?</DialogTitle>
            <DialogDescription>This will remove all {participants.length} participants. This action cannot be undone.</DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowClearConfirm(false)}>Cancel</Button>
            <Button variant="destructive" onClick={handleClearAll}>Clear All</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Multi Draw Dialog */}
      <Dialog open={showMultiDraw} onOpenChange={setShowMultiDraw}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Multi Draw</DialogTitle>
            <DialogDescription>How many winners to draw? (max {participants.length})</DialogDescription>
          </DialogHeader>
          <Input type="number" min={2} max={participants.length} value={multiCount} onChange={(e) => setMultiCount(Number(e.target.value))} />
          <DialogFooter>
            <Button onClick={() => handleDraw(multiCount)} disabled={multiCount < 1 || multiCount > participants.length}>
              Draw {multiCount} Winners
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Clear History Confirm Dialog */}
      <Dialog open={showClearHistory} onOpenChange={setShowClearHistory}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Clear Draw History?</DialogTitle>
            <DialogDescription>This will delete all {draws.length} draw records. This action cannot be undone.</DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowClearHistory(false)}>Cancel</Button>
            <Button variant="destructive" onClick={async () => { await clearDrawHistory(); setShowClearHistory(false); }}>Clear History</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
