import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";

type Participant = { id: string; name: string; created_at: string };

export function useParticipants() {
  const [participants, setParticipants] = useState<Participant[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchParticipants = async () => {
    const { data } = await supabase
      .from("participants")
      .select("*")
      .order("created_at", { ascending: true });
    setParticipants(data || []);
    setLoading(false);
  };

  useEffect(() => {
    fetchParticipants();

    const channel = supabase
      .channel("participants-realtime")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "participants" },
        () => fetchParticipants()
      )
      .subscribe();

    return () => { supabase.removeChannel(channel); };
  }, []);

  const addParticipant = async (name: string) => {
    const { error } = await supabase.from("participants").insert({ name: name.trim() });
    return { error };
  };

  const addBulkParticipants = async (names: string[]) => {
    const rows = names.filter((n) => n.trim()).map((n) => ({ name: n.trim() }));
    if (rows.length === 0) return { error: null };
    const { error } = await supabase.from("participants").insert(rows);
    return { error };
  };

  const updateParticipant = async (id: string, name: string) => {
    const { error } = await supabase.from("participants").update({ name }).eq("id", id);
    return { error };
  };

  const deleteParticipant = async (id: string) => {
    const { error } = await supabase.from("participants").delete().eq("id", id);
    return { error };
  };

  const clearAll = async () => {
    const { error } = await supabase.from("participants").delete().neq("id", "00000000-0000-0000-0000-000000000000");
    return { error };
  };

  return { participants, loading, addParticipant, addBulkParticipants, updateParticipant, deleteParticipant, clearAll };
}
