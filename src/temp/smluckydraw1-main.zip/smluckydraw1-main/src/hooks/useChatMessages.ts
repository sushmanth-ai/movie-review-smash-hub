import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

// reactions is a map of emoji -> array of user names who reacted
export type Reactions = Record<string, string[]>;

export interface ChatMessage {
  id: string;
  name: string;
  message: string;
  reactions: Reactions;
  reply_to: string | null;
  created_at: string;
}

export function useChatMessages() {
  const [messages, setMessages] = useState<ChatMessage[]>([]);

  useEffect(() => {
    const cutoff = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();

    const fetchMessages = async () => {
      const { data } = await supabase
        .from("chat_messages")
        .select("*")
        .gte("created_at", cutoff)
        .order("created_at", { ascending: true })
        .limit(100);
      if (data) setMessages(data.map(normalizeMsg));
    };
    fetchMessages();

    const channel = supabase
      .channel("chat_messages_realtime")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "chat_messages" },
        (payload) => {
          if (payload.eventType === "INSERT") {
            setMessages((prev) => [...prev.slice(-99), normalizeMsg(payload.new as any)]);
          } else if (payload.eventType === "UPDATE") {
            const updated = normalizeMsg(payload.new as any);
            setMessages((prev) => prev.map((m) => (m.id === updated.id ? updated : m)));
          }
        }
      )
      .subscribe();

    // Periodically remove expired messages (older than 24h)
    const cleanup = setInterval(() => {
      const cutoffMs = Date.now() - 24 * 60 * 60 * 1000;
      setMessages((prev) => prev.filter((m) => new Date(m.created_at).getTime() > cutoffMs));
    }, 60_000);

    return () => {
      supabase.removeChannel(channel);
      clearInterval(cleanup);
    };
  }, []);

  const sendMessage = async (name: string, message: string, replyTo?: string) => {
    await supabase.from("chat_messages").insert({
      name,
      message,
      ...(replyTo ? { reply_to: replyTo } : {}),
    } as any);
  };

  const toggleReaction = async (messageId: string, emoji: string, userName: string) => {
    const msg = messages.find((m) => m.id === messageId);
    if (!msg) return;

    const current = { ...msg.reactions };
    const users = current[emoji] || [];

    if (users.includes(userName)) {
      current[emoji] = users.filter((u) => u !== userName);
      if (current[emoji].length === 0) delete current[emoji];
    } else {
      current[emoji] = [...users, userName];
    }

    await supabase.from("chat_messages").update({ reactions: current as any }).eq("id", messageId);
  };

  return { messages, sendMessage, toggleReaction };
}

function normalizeMsg(row: any): ChatMessage {
  return {
    ...row,
    reactions: (row.reactions && typeof row.reactions === "object" ? row.reactions : {}) as Reactions,
    reply_to: row.reply_to || null,
  };
}
