import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

function getSessionKey() {
  let key = localStorage.getItem("viewer_presence_key");
  if (!key) {
    key = crypto.randomUUID();
    localStorage.setItem("viewer_presence_key", key);
  }
  return key;
}

export function useViewerCount() {
  const [count, setCount] = useState(0);

  useEffect(() => {
    const presenceKey = getSessionKey();

    const channel = supabase.channel("viewers", {
      config: { presence: { key: presenceKey } },
    });

    channel
      .on("presence", { event: "sync" }, () => {
        const state = channel.presenceState();
        setCount(Object.keys(state).length);
      })
      .on("presence", { event: "join" }, () => {
        const state = channel.presenceState();
        setCount(Object.keys(state).length);
      })
      .on("presence", { event: "leave" }, () => {
        const state = channel.presenceState();
        setCount(Object.keys(state).length);
      })
      .subscribe(async (status) => {
        if (status === "SUBSCRIBED") {
          await channel.track({ online_at: new Date().toISOString() });
        }
      });

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  return count;
}
