import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";

type DrawState = {
  id: string;
  status: "idle" | "shuffling" | "winner";
  winner_names: string[] | null;
  total_winners: number | null;
  current_winner_index: number | null;
  updated_at: string;
  countdown_target: string | null;
};

type Draw = {
  id: string;
  winner_names: string[];
  participant_count: number;
  created_at: string;
};

export function useDrawState() {
  const [drawState, setDrawState] = useState<DrawState | null>(null);
  const [draws, setDraws] = useState<Draw[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchDrawState = async () => {
    const { data } = await supabase.from("draw_state").select("*").limit(1).maybeSingle();
    if (data) setDrawState(data);
    setLoading(false);
  };

  const fetchDraws = async () => {
    const { data } = await supabase.from("draws").select("*").order("created_at", { ascending: false });
    setDraws(data || []);
  };

  useEffect(() => {
    fetchDrawState();
    fetchDraws();

    const stateChannel = supabase
      .channel("draw-state-realtime")
      .on("postgres_changes", { event: "*", schema: "public", table: "draw_state" }, () => fetchDrawState())
      .subscribe();

    const drawsChannel = supabase
      .channel("draws-realtime")
      .on("postgres_changes", { event: "*", schema: "public", table: "draws" }, () => fetchDraws())
      .subscribe();

    return () => {
      supabase.removeChannel(stateChannel);
      supabase.removeChannel(drawsChannel);
    };
  }, []);

  const startDraw = async (count: number = 1) => {
    const { data: { session } } = await supabase.auth.getSession();
    const response = await supabase.functions.invoke("perform-draw", {
      body: { count },
      headers: { Authorization: `Bearer ${session?.access_token}` },
    });
    return response;
  };

  const deleteDraw = async (id: string) => {
    const { error } = await supabase.from("draws").delete().eq("id", id);
    return { error };
  };

  const clearDrawHistory = async () => {
    const { error } = await supabase.from("draws").delete().neq("id", "00000000-0000-0000-0000-000000000000");
    return { error };
  };

  const setCountdown = async (minutes: number) => {
    const { data: rows } = await supabase.from("draw_state").select("id").limit(1).maybeSingle();
    if (!rows) return;
    const target = new Date(Date.now() + minutes * 60 * 1000).toISOString();
    await supabase.from("draw_state").update({ countdown_target: target }).eq("id", rows.id);
  };

  const clearCountdown = async () => {
    const { data: rows } = await supabase.from("draw_state").select("id").limit(1).maybeSingle();
    if (!rows) return;
    await supabase.from("draw_state").update({ countdown_target: null }).eq("id", rows.id);
  };

  return { drawState, draws, loading, startDraw, deleteDraw, clearDrawHistory, setCountdown, clearCountdown };
}
