import { useState, useRef, useEffect, useMemo } from "react";
import { useChatMessages, type Reactions, type ChatMessage } from "@/hooks/useChatMessages";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { MessageCircle, Send, X, SmilePlus, Reply, CornerDownRight } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const EMOJI_PICKER = ["😀", "😂", "🥰", "😍", "🤩", "😎", "🥳", "🤯", "😢", "🔥", "❤️", "👍", "👎", "👏", "🎉", "💯", "🙏", "✨", "💀", "🤔"];
const REACTION_EMOJIS = ["❤️", "😂", "🔥", "👍", "👏", "🎉"];

const NAME_COLORS = [
  "hsl(340 80% 65%)",
  "hsl(200 80% 60%)",
  "hsl(140 60% 55%)",
  "hsl(30 90% 60%)",
  "hsl(270 70% 65%)",
  "hsl(50 85% 55%)",
  "hsl(170 70% 50%)",
  "hsl(0 75% 60%)",
  "hsl(220 70% 65%)",
  "hsl(310 65% 60%)",
];

function getNameColor(name: string): string {
  let hash = 0;
  for (let i = 0; i < name.length; i++) {
    hash = name.charCodeAt(i) + ((hash << 5) - hash);
  }
  return NAME_COLORS[Math.abs(hash) % NAME_COLORS.length];
}

export default function LiveChat() {
  const { messages, sendMessage, toggleReaction } = useChatMessages();
  const [open, setOpen] = useState(false);
  const [name, setName] = useState(() => localStorage.getItem("chat_name") || "");
  const [nameSet, setNameSet] = useState(() => !!localStorage.getItem("chat_name"));
  const [text, setText] = useState("");
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [reactionMsgId, setReactionMsgId] = useState<string | null>(null);
  const [replyTo, setReplyTo] = useState<ChatMessage | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Build a lookup map for replied messages
  const msgMap = useMemo(() => {
    const map = new Map<string, ChatMessage>();
    messages.forEach((m) => map.set(m.id, m));
    return map;
  }, [messages]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, open]);

  const handleSetName = () => {
    if (name.trim()) {
      localStorage.setItem("chat_name", name.trim());
      setNameSet(true);
    }
  };

  const handleSend = async () => {
    if (!text.trim()) return;
    await sendMessage(name, text.trim(), replyTo?.id);
    setText("");
    setReplyTo(null);
    setShowEmojiPicker(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      if (!nameSet) handleSetName();
      else handleSend();
    }
    if (e.key === "Escape" && replyTo) {
      setReplyTo(null);
    }
  };

  const handleReply = (msg: ChatMessage) => {
    setReplyTo(msg);
    setReactionMsgId(null);
    inputRef.current?.focus();
  };

  const insertEmoji = (emoji: string) => {
    setText((prev) => prev + emoji);
    setShowEmojiPicker(false);
  };

  const handleReaction = async (messageId: string, emoji: string) => {
    await toggleReaction(messageId, emoji, name);
    setReactionMsgId(null);
  };

  return (
    <>
      {/* Floating button */}
      <AnimatePresence>
        {!open && (
          <motion.button
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            exit={{ scale: 0 }}
            onClick={() => setOpen(true)}
            className="fixed bottom-6 right-6 z-50 flex h-14 w-14 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-lg hover:bg-primary/90 transition-colors"
          >
            <MessageCircle className="h-6 w-6" />
            {messages.length > 0 && (
              <span className="absolute -right-1 -top-1 flex h-5 w-5 items-center justify-center rounded-full bg-destructive text-[10px] font-bold text-destructive-foreground">
                {messages.length > 99 ? "99+" : messages.length}
              </span>
            )}
          </motion.button>
        )}
      </AnimatePresence>

      {/* Chat panel */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 40, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 40, scale: 0.95 }}
            className="fixed bottom-6 right-6 z-50 flex h-[440px] w-[340px] flex-col rounded-2xl border border-border/50 bg-card/95 shadow-2xl backdrop-blur-xl"
          >
            {/* Header */}
            <div className="flex items-center justify-between border-b border-border/50 px-4 py-3">
              <div className="flex items-center gap-2">
                <MessageCircle className="h-4 w-4 text-primary" />
                <span className="font-semibold text-sm">Live Chat</span>
                <span className="rounded-full bg-primary/20 px-2 py-0.5 text-[10px] font-medium text-primary">LIVE</span>
              </div>
              <button onClick={() => setOpen(false)} className="text-muted-foreground hover:text-foreground transition-colors">
                <X className="h-4 w-4" />
              </button>
            </div>

            {!nameSet ? (
              <div className="flex flex-1 flex-col items-center justify-center gap-3 p-6">
                <p className="text-sm text-muted-foreground text-center">Enter your name to join the chat</p>
                <Input
                  placeholder="Your name..."
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  onKeyDown={handleKeyDown}
                  maxLength={30}
                  className="bg-secondary/50"
                />
                <Button onClick={handleSetName} disabled={!name.trim()} className="w-full">
                  Join Chat
                </Button>
              </div>
            ) : (
              <>
                {/* Messages */}
                <div ref={scrollRef} className="flex-1 overflow-y-auto p-3 space-y-2">
                  {messages.length === 0 && (
                    <p className="text-center text-xs text-muted-foreground pt-8">No messages yet. Say hi! 👋</p>
                  )}
                  {messages.map((msg) => {
                    const isMe = msg.name === name;
                    const repliedMsg = msg.reply_to ? msgMap.get(msg.reply_to) : null;
                    return (
                      <motion.div
                        key={msg.id}
                        initial={{ opacity: 0, y: 8 }}
                        animate={{ opacity: 1, y: 0 }}
                        className={`group flex flex-col ${isMe ? "items-end" : "items-start"}`}
                      >
                        <span className="text-[10px] font-semibold mb-0.5 px-1" style={{ color: getNameColor(msg.name) }}>{msg.name}</span>

                        <div className="relative">
                          <div
                            className={`max-w-[220px] rounded-xl px-3 py-1.5 text-sm break-words ${
                              isMe
                                ? "bg-primary text-primary-foreground rounded-br-sm"
                                : "bg-secondary/80 text-foreground rounded-bl-sm"
                            }`}
                          >
                            {/* Reply quote */}
                            {repliedMsg && (
                              <div className={`mb-1 flex items-start gap-1 rounded-md px-2 py-1 text-[11px] ${
                                isMe ? "bg-primary-foreground/15" : "bg-foreground/10"
                              }`}>
                                <CornerDownRight className="mt-0.5 h-3 w-3 flex-shrink-0 opacity-60" />
                                <div className="min-w-0">
                                  <span className="font-semibold block" style={{ color: isMe ? undefined : getNameColor(repliedMsg.name) }}>
                                    {repliedMsg.name}
                                  </span>
                                  <span className="opacity-80 line-clamp-1">{repliedMsg.message}</span>
                                </div>
                              </div>
                            )}
                            {msg.message}
                          </div>

                          {/* Action buttons (reply + reaction) */}
                          <div className={`absolute -bottom-1 ${isMe ? "-left-12" : "-right-12"} flex gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity`}>
                            <button
                              onClick={() => handleReply(msg)}
                              className="text-muted-foreground hover:text-foreground"
                              title="Reply"
                            >
                              <Reply className="h-3.5 w-3.5" />
                            </button>
                            <button
                              onClick={() => setReactionMsgId(reactionMsgId === msg.id ? null : msg.id)}
                              className="text-muted-foreground hover:text-foreground"
                            >
                              <SmilePlus className="h-3.5 w-3.5" />
                            </button>
                          </div>

                          {/* Reaction picker */}
                          <AnimatePresence>
                            {reactionMsgId === msg.id && (
                              <motion.div
                                initial={{ opacity: 0, scale: 0.9 }}
                                animate={{ opacity: 1, scale: 1 }}
                                exit={{ opacity: 0, scale: 0.9 }}
                                className={`absolute ${isMe ? "right-0" : "left-0"} -top-9 z-10 flex gap-0.5 rounded-full border border-border/50 bg-card px-2 py-1 shadow-lg`}
                              >
                                {REACTION_EMOJIS.map((emoji) => (
                                  <button
                                    key={emoji}
                                    onClick={() => handleReaction(msg.id, emoji)}
                                    className="hover:scale-125 transition-transform text-sm px-0.5"
                                  >
                                    {emoji}
                                  </button>
                                ))}
                              </motion.div>
                            )}
                          </AnimatePresence>
                        </div>

                        {/* Displayed reactions */}
                        <ReactionBadges reactions={msg.reactions} messageId={msg.id} userName={name} onToggle={toggleReaction} />
                      </motion.div>
                    );
                  })}
                </div>

                {/* Emoji picker */}
                <AnimatePresence>
                  {showEmojiPicker && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 10 }}
                      className="border-t border-border/50 p-2"
                    >
                      <div className="grid grid-cols-10 gap-1">
                        {EMOJI_PICKER.map((emoji) => (
                          <button
                            key={emoji}
                            onClick={() => insertEmoji(emoji)}
                            className="flex h-7 w-7 items-center justify-center rounded hover:bg-secondary/80 transition-colors text-base"
                          >
                            {emoji}
                          </button>
                        ))}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>

                {/* Reply preview bar */}
                <AnimatePresence>
                  {replyTo && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      exit={{ opacity: 0, height: 0 }}
                      className="border-t border-border/50 px-3 py-2 flex items-center gap-2"
                    >
                      <Reply className="h-3.5 w-3.5 text-primary flex-shrink-0" />
                      <div className="min-w-0 flex-1">
                        <span className="text-[10px] font-semibold block" style={{ color: getNameColor(replyTo.name) }}>
                          {replyTo.name}
                        </span>
                        <span className="text-[11px] text-muted-foreground line-clamp-1">{replyTo.message}</span>
                      </div>
                      <button onClick={() => setReplyTo(null)} className="text-muted-foreground hover:text-foreground flex-shrink-0">
                        <X className="h-3.5 w-3.5" />
                      </button>
                    </motion.div>
                  )}
                </AnimatePresence>

                {/* Input */}
                <div className="border-t border-border/50 p-3">
                  <div className="flex gap-2">
                    <button
                      onClick={() => setShowEmojiPicker(!showEmojiPicker)}
                      className="flex-shrink-0 text-muted-foreground hover:text-foreground transition-colors"
                    >
                      <SmilePlus className="h-5 w-5" />
                    </button>
                    <Input
                      ref={inputRef}
                      placeholder="Type a message..."
                      value={text}
                      onChange={(e) => setText(e.target.value)}
                      onKeyDown={handleKeyDown}
                      maxLength={200}
                      className="bg-secondary/50 text-sm"
                    />
                    <Button size="icon" onClick={handleSend} disabled={!text.trim()}>
                      <Send className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}

function ReactionBadges({
  reactions,
  messageId,
  userName,
  onToggle,
}: {
  reactions: Reactions;
  messageId: string;
  userName: string;
  onToggle: (id: string, emoji: string, name: string) => void;
}) {
  const entries = Object.entries(reactions).filter(([, users]) => users.length > 0);
  if (entries.length === 0) return null;

  return (
    <div className="flex flex-wrap gap-1 mt-1 px-1">
      {entries.map(([emoji, users]) => {
        const reacted = users.includes(userName);
        return (
          <button
            key={emoji}
            onClick={() => onToggle(messageId, emoji, userName)}
            className={`flex items-center gap-0.5 rounded-full px-1.5 py-0.5 text-[11px] border transition-colors ${
              reacted
                ? "border-primary/50 bg-primary/10 text-primary"
                : "border-border/50 bg-secondary/30 text-muted-foreground hover:bg-secondary/60"
            }`}
          >
            <span>{emoji}</span>
            <span className="font-medium">{users.length}</span>
          </button>
        );
      })}
    </div>
  );
}
