
-- Add reactions column to chat_messages
ALTER TABLE public.chat_messages ADD COLUMN reactions jsonb NOT NULL DEFAULT '{}'::jsonb;
