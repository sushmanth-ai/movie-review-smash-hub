
-- Role enum
CREATE TYPE public.app_role AS ENUM ('admin');

-- User roles table
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  role app_role NOT NULL,
  UNIQUE (user_id, role)
);
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

-- Helper: check admin role (security definer to avoid recursion)
CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role app_role)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id AND role = _role
  )
$$;

-- Convenience: is current user admin?
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT public.has_role(auth.uid(), 'admin')
$$;

-- RLS on user_roles: only admin can see/manage
CREATE POLICY "Admin full access to user_roles" ON public.user_roles
  FOR ALL TO authenticated USING (public.is_admin()) WITH CHECK (public.is_admin());

-- Participants table
CREATE TABLE public.participants (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.participants ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view participants" ON public.participants
  FOR SELECT USING (true);
CREATE POLICY "Admin can insert participants" ON public.participants
  FOR INSERT TO authenticated WITH CHECK (public.is_admin());
CREATE POLICY "Admin can update participants" ON public.participants
  FOR UPDATE TO authenticated USING (public.is_admin());
CREATE POLICY "Admin can delete participants" ON public.participants
  FOR DELETE TO authenticated USING (public.is_admin());

-- Draw state table (single row, tracks current draw status)
CREATE TYPE public.draw_status AS ENUM ('idle', 'shuffling', 'winner');

CREATE TABLE public.draw_state (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  status draw_status NOT NULL DEFAULT 'idle',
  winner_names TEXT[] DEFAULT '{}',
  total_winners INT DEFAULT 1,
  current_winner_index INT DEFAULT 0,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.draw_state ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view draw_state" ON public.draw_state
  FOR SELECT USING (true);
CREATE POLICY "Admin can update draw_state" ON public.draw_state
  FOR UPDATE TO authenticated USING (public.is_admin());
CREATE POLICY "Admin can insert draw_state" ON public.draw_state
  FOR INSERT TO authenticated WITH CHECK (public.is_admin());

-- Insert initial idle state
INSERT INTO public.draw_state (status) VALUES ('idle');

-- Draws history table
CREATE TABLE public.draws (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  winner_names TEXT[] NOT NULL,
  participant_count INT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.draws ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view draws" ON public.draws
  FOR SELECT USING (true);
CREATE POLICY "Admin can insert draws" ON public.draws
  FOR INSERT TO authenticated WITH CHECK (public.is_admin());

-- Enable realtime for live updates
ALTER PUBLICATION supabase_realtime ADD TABLE public.participants;
ALTER PUBLICATION supabase_realtime ADD TABLE public.draw_state;
ALTER PUBLICATION supabase_realtime ADD TABLE public.draws;
