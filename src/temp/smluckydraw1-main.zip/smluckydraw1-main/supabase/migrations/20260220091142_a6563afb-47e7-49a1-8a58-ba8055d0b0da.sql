
-- Add reply_to column for threaded replies
ALTER TABLE public.chat_messages ADD COLUMN reply_to uuid REFERENCES public.chat_messages(id) ON DELETE SET NULL;
