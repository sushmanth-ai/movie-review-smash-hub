
-- Allow anyone to update reactions on chat messages
CREATE POLICY "Anyone can update chat reactions" ON public.chat_messages FOR UPDATE USING (true) WITH CHECK (true);
