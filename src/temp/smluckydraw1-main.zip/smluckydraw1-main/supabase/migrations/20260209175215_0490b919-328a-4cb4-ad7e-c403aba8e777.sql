-- Allow admin to delete draw history
CREATE POLICY "Admin can delete draws"
ON public.draws
FOR DELETE
USING (is_admin());
