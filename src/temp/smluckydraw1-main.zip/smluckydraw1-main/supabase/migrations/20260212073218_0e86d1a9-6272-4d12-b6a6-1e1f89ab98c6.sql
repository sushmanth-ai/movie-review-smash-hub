
ALTER TABLE public.draw_state 
ADD COLUMN countdown_target timestamptz DEFAULT NULL;
