import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseAdmin = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    // Verify the user is admin
    const supabaseUser = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } }
    );
    const { data: { user } } = await supabaseUser.auth.getUser();
    if (!user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { data: roleData } = await supabaseAdmin
      .from("user_roles")
      .select("role")
      .eq("user_id", user.id)
      .eq("role", "admin")
      .maybeSingle();

    if (!roleData) {
      return new Response(JSON.stringify({ error: "Not an admin" }), {
        status: 403,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { count: winnerCount } = await req.json();
    const numWinners = Math.max(1, parseInt(String(winnerCount || "1")));

    // Get all participants
    const { data: participants } = await supabaseAdmin
      .from("participants")
      .select("*");

    if (!participants || participants.length === 0) {
      return new Response(JSON.stringify({ error: "No participants" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (numWinners > participants.length) {
      return new Response(JSON.stringify({ error: "Not enough participants" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Fair random selection using Fisher-Yates shuffle
    const shuffled = [...participants];
    for (let i = shuffled.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    const winners = shuffled.slice(0, numWinners);
    const winnerNames = winners.map((w) => w.name);

    // Set draw state to shuffling
    const { data: drawStateRows } = await supabaseAdmin
      .from("draw_state")
      .select("id")
      .limit(1);
    
    const drawStateId = drawStateRows?.[0]?.id;

    await supabaseAdmin.from("draw_state").update({
      status: "shuffling",
      winner_names: winnerNames,
      total_winners: numWinners,
      current_winner_index: 0,
      updated_at: new Date().toISOString(),
    }).eq("id", drawStateId);

    // Wait for animation duration then reveal winner
    // We use a timeout approach - the client handles animation,
    // after 6 seconds we update to winner state
    await new Promise((resolve) => setTimeout(resolve, 55000));

    await supabaseAdmin.from("draw_state").update({
      status: "winner",
      updated_at: new Date().toISOString(),
    }).eq("id", drawStateId);

    // Save to draw history
    await supabaseAdmin.from("draws").insert({
      winner_names: winnerNames,
      participant_count: participants.length,
    });

    // Remove winners from participants
    const winnerIds = winners.map((w) => w.id);
    await supabaseAdmin.from("participants").delete().in("id", winnerIds);

    // After a delay, reset to idle
    await new Promise((resolve) => setTimeout(resolve, 10000));
    await supabaseAdmin.from("draw_state").update({
      status: "idle",
      winner_names: [],
      total_winners: 1,
      current_winner_index: 0,
      updated_at: new Date().toISOString(),
    }).eq("id", drawStateId);

    return new Response(JSON.stringify({ success: true, winners: winnerNames }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    return new Response(JSON.stringify({ error: e.message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
