

# 🎰 SM Lucky Draw — Real-Time Lucky Draw Website

## Overview
A production-ready lucky draw application with a single admin managing participants and draws, and a public-facing live view where anyone can watch the animated draw and winner reveal in real time. Powered by Supabase for auth, database, and real-time sync.

---

## 1. Admin Login (Simple Password)
- A single admin login page with a password-only field
- Password stored securely in the database (not hardcoded)
- Session persists via Supabase auth (a single pre-created admin account)
- Public users never see admin controls

## 2. Admin Dashboard
- **Add Participants**: Single name input + bulk paste/import (one name per line)
- **Participant List**: Editable table with inline edit and delete per name
- **Clear All** button with confirmation dialog
- **Draw Controls**:
  - "Start Lucky Draw" button (single winner)
  - "Start Multi Draw" button with input for how many winners to pick
- **Draw History**: Table of past draws showing date, winner(s), and participant count

## 3. Public Live View (No Login)
- Clean landing page showing:
  - "SM Lucky Draw" header/branding
  - Live participant list (read-only, updates in real time)
  - Animated draw area (centered, prominent)
  - Winner display section
- All changes from admin (adding/removing participants, starting draw) appear instantly

## 4. Lucky Draw Animation & Selection
- When admin clicks "Start", a **slot-machine / roulette-style shuffle animation** plays for ~5–8 seconds
- Names cycle rapidly, then slow down to land on the winner
- The animation is triggered via a real-time event so **all viewers see it simultaneously**
- Winner reveal: large bold name with **confetti explosion** and glow effect
- For multi-draw: winners are picked sequentially with animation for each

## 5. Winner Handling
- Winners are **automatically removed** from the participant pool after being drawn
- Winners are saved to a draw history table with timestamp
- Admin can view full draw history from the dashboard

## 6. Real-Time Sync (Supabase Realtime)
- Participant list updates live for all viewers when admin adds/removes names
- Draw state (idle → shuffling → winner) is broadcast in real time
- Uses Supabase Realtime channels for instant updates across all connected clients

## 7. UI & Design
- **Dark mode by default** with optional light mode toggle
- Modern, clean design with smooth animations and transitions
- Fully responsive: works on mobile, tablet, and desktop
- Sections: Header → Participant List → Draw Area → Winner Display → History

## 8. Backend (Supabase / Lovable Cloud)
- **Tables**: `participants`, `draws` (history), `draw_state` (current draw status)
- **Auth**: Single admin account via Supabase Auth
- **RLS**: Admin has full access; public users have read-only access to participants, draws, and draw state
- **Realtime**: Subscriptions on participant list and draw state for live updates

